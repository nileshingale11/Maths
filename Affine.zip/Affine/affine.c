#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "numbers.h"

int main() {
	int i = 0, a, b;
	char plaint[250];
	printf("Enter article.\n");
	gets(plaint);
	
	printf("Enter keys a & b:\n");
	scanf("%d%d", &a, &b);
	
	char *cipher, *dcipher;
	
	cipher = (char *) malloc (sizeof(char) * (strlen(plaint) + 1));
	
	encipher(plaint, cipher, a, b);
	puts(cipher);
	
	dcipher = (char *) malloc (sizeof(char) * (strlen(cipher) + 1));
	decipher(cipher, dcipher, a, b);
	
	puts(dcipher);
	
	return(0);
}

//The essence of the free press is the reliable responsible and moral nature of freedom The character of the consored press is the nondescript confusion of tyranny
