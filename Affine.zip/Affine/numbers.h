// List of functions

int addinv(int a, int n) {
	if (a % n == 0)
		return (a);
	else
		return (n - a);
}

int multinv(int n, int m) {
	int i;
	for (i = 1; i < m; i++) {
		if((i * n) % m == 1) {
			return(i);
		}
	}
}

void encipher(char pt[], char ct[], int a, int b) {
	int i = 0;
	while (pt[i] != '\0') {
		if (pt[i] >= 'a' && pt[i] <= 'z') {
			if (pt[i] == ' ')
				ct[i] = ' ';
			else
				ct[i] = 65 + ((a * (pt[i] - 97) + b) % 26);
			i++;
		} else {
			if (pt[i] == ' ')
				ct[i] = ' ';
			else
				ct[i] = 97 + ((a * (pt[i] - 65) + b) % 26);
			i++;
		}		
	}
	ct[i] = '\0';
}

void decipher(char ct[], char pt[], int a, int b) {
	int i;
	while (ct[i] != '\0') {
		if (ct[i] >= 'A' && ct[i] <= 'Z') {
			if (ct[i] == ' ')
				pt[i] = ' ';
			else
				pt[i] = 97 + (((multinv(a, 26) * (ct[i] - 65)) + (addinv(b, 26) * multinv(a, 26))) % 26);
			i++;
		} else {
			if (ct[i] == ' ')
				pt[i] = ' ';
			else
				pt[i] = 65 + (((multinv(a, 26) * (ct[i] - 97)) + (addinv(b, 26) * multinv(a, 26))) % 26);
			i++;
		}		
	}
	pt[i] = '\0';
}
